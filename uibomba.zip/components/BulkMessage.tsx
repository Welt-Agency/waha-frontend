'use client';

import { useState, useEffect } from 'react';
import { Send, MessageSquare, Users, RefreshCw, AlertCircle, CheckCircle, Zap, RotateCcw, Clock, Info, Play, Pause, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { authenticatedFetch } from '@/lib/auth';

interface Session {
  id: string;
  name: string;
  label: string;
  phone: string;
  status: string;
}

interface APISession {
  name: string;
  status: string;
  config: {
    metadata: any;
    webhooks: any[];
  };
  me?: {
    id: string;
    pushName: string;
    jid: string;
  };
  assignedWorker: string;
}

interface BulkMessageResult {
  phoneNumber: string;
  status: 'success' | 'error' | 'pending';
  message?: string;
  sessionUsed?: string;
  timestamp: string;
}

export default function BulkMessage() {
  const [phoneNumbers, setPhoneNumbers] = useState('');
  const [messageContent, setMessageContent] = useState('');
  const [useRotation, setUseRotation] = useState(false);
  const [useAI, setUseAI] = useState(false);
  const [selectedSessions, setSelectedSessions] = useState<string[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [loading, setLoading] = useState(false);
  const [sessionsLoading, setSessionsLoading] = useState(true);
  const [results, setResults] = useState<BulkMessageResult[]>([]);
  const [progress, setProgress] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [delaySeconds, setDelaySeconds] = useState(2);
  const [currentSendingIndex, setCurrentSendingIndex] = useState(0);
  const [estimatedTimeLeft, setEstimatedTimeLeft] = useState(0);

  // API'den session'ları çek
  const fetchSessions = async () => {
    try {
      setSessionsLoading(true);
      const response = await authenticatedFetch('/sessions');
      if (!response.ok) throw new Error('Session verileri alınamadı');
      
      const apiSessions: APISession[] = await response.json();
      const formattedSessions: Session[] = apiSessions
        .filter(session => session.me && session.me.id && session.status === 'WORKING')
        .map((session, index) => ({
          id: session.name,
          name: session.name,
          label: session.me!.pushName || `Session ${index + 1}`,
          phone: session.me!.id.replace('@c.us', ''),
          status: session.status
        }));
      
      setSessions(formattedSessions);
    } catch (err) {
      console.error('Error fetching sessions:', err);
    } finally {
      setSessionsLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  // Telefon numaralarını parse et ve validate et
  const parsePhoneNumbers = (text: string): string[] => {
    return text
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0)
      .map(line => line.replace(/[\s\+\-\(\)]/g, ''))
      .filter(line => /^90\d{10}$/.test(line)); // Türkiye formatı kontrolü
  };

  // Session seçimi handle et
  const handleSessionToggle = (sessionId: string) => {
    setSelectedSessions(prev => 
      prev.includes(sessionId) 
        ? prev.filter(id => id !== sessionId)
        : [...prev, sessionId]
    );
  };

  // Tüm session'ları seç/kaldır
  const handleSelectAllSessions = () => {
    if (selectedSessions.length === sessions.length) {
      setSelectedSessions([]);
    } else {
      setSelectedSessions(sessions.map(s => s.id));
    }
  };

  // AI ile mesajı özelleştir (geliştirilmiş)
  const customizeMessageWithAI = (originalMessage: string, phoneNumber: string): string => {
    const greetings = ['Merhaba', 'Selam', 'İyi günler', 'Merhaba değerli müşterimiz', 'Selam'];
    const endings = ['', ' 🙂', ' 😊', ' 👋', ''];
    const connectors = ['', ', ', '! ', ' - '];
    
    const greeting = greetings[Math.floor(Math.random() * greetings.length)];
    const ending = endings[Math.floor(Math.random() * endings.length)];
    const connector = connectors[Math.floor(Math.random() * connectors.length)];
    
    return `${greeting}${connector}${originalMessage}${ending}`;
  };

  // Tahmini süre hesapla
  const calculateEstimatedTime = (phoneCount: number, delay: number): string => {
    const totalSeconds = phoneCount * delay;
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    
    if (minutes > 0) {
      return `${minutes} dakika ${seconds} saniye`;
    }
    return `${seconds} saniye`;
  };

  // Toplu mesaj gönder
  const handleBulkSend = async () => {
    if (!messageContent.trim()) {
      alert('Lütfen mesaj içeriğini girin');
      return;
    }

    const numbers = parsePhoneNumbers(phoneNumbers);
    if (numbers.length === 0) {
      alert('Lütfen en az bir geçerli telefon numarası girin (90XXXXXXXXXX formatında)');
      return;
    }

    if (!useRotation && selectedSessions.length === 0) {
      alert('Lütfen en az bir session seçin veya rotasyon özelliğini aktif edin');
      return;
    }

    setIsSending(true);
    setIsPaused(false);
    setResults([]);
    setProgress(0);
    setCurrentSendingIndex(0);

    const bulkResults: BulkMessageResult[] = [];
    const availableSessions = useRotation ? sessions : sessions.filter(s => selectedSessions.includes(s.id));
    
    if (availableSessions.length === 0) {
      alert('Kullanılabilir session bulunamadı');
      setIsSending(false);
      return;
    }

    const startTime = Date.now();
    
    for (let i = 0; i < numbers.length; i++) {
      // Duraklatma kontrolü
      while (isPaused) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      if (!isSending) break; // Durdurulmuşsa çık

      setCurrentSendingIndex(i + 1);
      
      const phoneNumber = numbers[i];
      const sessionIndex = useRotation ? i % availableSessions.length : Math.floor(Math.random() * availableSessions.length);
      const selectedSession = availableSessions[sessionIndex];
      
      // AI ile mesajı özelleştir
      const finalMessage = useAI 
        ? customizeMessageWithAI(messageContent, phoneNumber)
        : messageContent;

      const timestamp = new Date().toLocaleTimeString('tr-TR');

      try {
        const chatId = `${phoneNumber}@c.us`;
        
        const response = await authenticatedFetch('/send-text', {
          method: 'POST',
          body: JSON.stringify({
            chatId: chatId,
            reply_to: null,
            text: finalMessage,
            linkPreview: true,
            linkPreviewHighQuality: false,
            session: selectedSession.id
          })
        });

        if (response.ok) {
          bulkResults.push({
            phoneNumber: `+${phoneNumber}`,
            status: 'success',
            message: 'Mesaj başarıyla gönderildi',
            sessionUsed: selectedSession.label,
            timestamp
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          bulkResults.push({
            phoneNumber: `+${phoneNumber}`,
            status: 'error',
            message: errorData.message || 'Mesaj gönderilemedi',
            sessionUsed: selectedSession.label,
            timestamp
          });
        }
      } catch (error) {
        bulkResults.push({
          phoneNumber: `+${phoneNumber}`,
          status: 'error',
          message: 'Bağlantı hatası',
          sessionUsed: selectedSession.label,
          timestamp
        });
      }

      // Progress güncelle
      const progressPercent = ((i + 1) / numbers.length) * 100;
      setProgress(progressPercent);
      setResults([...bulkResults]);

      // Tahmini kalan süre
      const elapsedTime = Date.now() - startTime;
      const avgTimePerMessage = elapsedTime / (i + 1);
      const remainingMessages = numbers.length - (i + 1);
      const estimatedRemaining = Math.ceil((remainingMessages * avgTimePerMessage) / 1000);
      setEstimatedTimeLeft(estimatedRemaining);

      // Son mesaj değilse bekleme
      if (i < numbers.length - 1) {
        await new Promise(resolve => setTimeout(resolve, delaySeconds * 1000));
      }
    }

    setIsSending(false);
    setIsPaused(false);
    setCurrentSendingIndex(0);
    setEstimatedTimeLeft(0);
  };

  // Gönderimi duraklat/devam ettir
  const togglePause = () => {
    setIsPaused(!isPaused);
  };

  // Gönderimi durdur
  const stopSending = () => {
    setIsSending(false);
    setIsPaused(false);
    setCurrentSendingIndex(0);
    setEstimatedTimeLeft(0);
  };

  const phoneNumbersList = parsePhoneNumbers(phoneNumbers);
  const invalidNumbers = phoneNumbers.split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => line.replace(/[\s\+\-\(\)]/g, ''))
    .filter(line => line.length > 0 && !/^90\d{10}$/.test(line));
  
  const successCount = results.filter(r => r.status === 'success').length;
  const errorCount = results.filter(r => r.status === 'error').length;

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Toplu Mesaj Gönderimi</h1>
            <p className="text-gray-600">Birden fazla kişiye aynı anda mesaj gönderin</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button 
              onClick={fetchSessions}
              variant="outline"
              size="sm"
              disabled={sessionsLoading}
            >
              {sessionsLoading ? (
                <RefreshCw className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Yenile
            </Button>
            
            {/* Gönderim Kontrolleri */}
            {isSending && (
              <div className="flex items-center space-x-2">
                <Button
                  onClick={togglePause}
                  variant="outline"
                  size="sm"
                  className="text-yellow-600 hover:text-yellow-700"
                >
                  {isPaused ? (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Devam Et
                    </>
                  ) : (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      Duraklat
                    </>
                  )}
                </Button>
                <Button
                  onClick={stopSending}
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:text-red-700"
                >
                  <X className="h-4 w-4 mr-2" />
                  Durdur
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Sol Panel - Mesaj Hazırlama */}
        <div className="xl:col-span-2 space-y-6">
          {/* Telefon Numaraları */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-[#075E54]" />
                  <CardTitle>Telefon Numaraları</CardTitle>
                </div>
                <Badge variant="outline" className="text-sm">
                  {phoneNumbersList.length} geçerli numara
                </Badge>
              </div>
              <CardDescription>
                Her satıra bir telefon numarası girin (90XXXXXXXXXX formatında)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="905551234567&#10;905551234568&#10;905551234569"
                value={phoneNumbers}
                onChange={(e) => setPhoneNumbers(e.target.value)}
                className="min-h-[180px] font-mono text-sm"
              />
              <div className="mt-3 flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  {phoneNumbersList.length} geçerli numara
                  {invalidNumbers.length > 0 && (
                    <span className="text-red-600 ml-2">
                      • {invalidNumbers.length} geçersiz numara
                    </span>
                  )}
                </div>
                {phoneNumbersList.length > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    Tahmini süre: {calculateEstimatedTime(phoneNumbersList.length, delaySeconds)}
                  </Badge>
                )}
              </div>
              
              {invalidNumbers.length > 0 && (
                <Alert className="mt-3">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Geçersiz numaralar:</strong> {invalidNumbers.slice(0, 3).join(', ')}
                    {invalidNumbers.length > 3 && ` ve ${invalidNumbers.length - 3} tane daha`}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Mesaj İçeriği */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5 text-[#075E54]" />
                  <CardTitle>Mesaj İçeriği</CardTitle>
                </div>
                <Badge variant="outline" className="text-sm">
                  {messageContent.length} karakter
                </Badge>
              </div>
              <CardDescription>
                Gönderilecek mesajın içeriğini yazın
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Mesajınızı buraya yazın..."
                value={messageContent}
                onChange={(e) => setMessageContent(e.target.value)}
                className="min-h-[120px]"
              />
              {useAI && (
                <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-center space-x-2 text-yellow-800">
                    <Zap className="h-4 w-4" />
                    <span className="text-sm font-medium">AI Özgünleştirici Aktif</span>
                  </div>
                  <p className="text-sm text-yellow-700 mt-1">
                    Her mesaj farklı selamlamalar ile özelleştirilecek
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Gönderim Ayarları */}
          <Card>
            <CardHeader>
              <CardTitle>Gönderim Ayarları</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Mesaj Arası Bekleme */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-gray-600" />
                  <Label className="font-medium">Mesaj Arası Bekleme Süresi</Label>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex-1">
                    <Select value={delaySeconds.toString()} onValueChange={(value) => setDelaySeconds(Number(value))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 saniye</SelectItem>
                        <SelectItem value="2">2 saniye</SelectItem>
                        <SelectItem value="3">3 saniye</SelectItem>
                        <SelectItem value="5">5 saniye</SelectItem>
                        <SelectItem value="10">10 saniye</SelectItem>
                        <SelectItem value="30">30 saniye</SelectItem>
                        <SelectItem value="60">1 dakika</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="text-sm text-gray-600">
                    veya
                  </div>
                  <div className="w-24">
                    <Input
                      type="number"
                      min="1"
                      max="300"
                      value={delaySeconds}
                      onChange={(e) => setDelaySeconds(Math.max(1, Math.min(300, Number(e.target.value) || 1)))}
                      className="text-center"
                    />
                  </div>
                  <span className="text-sm text-gray-600">saniye</span>
                </div>
                <p className="text-sm text-gray-600">
                  Spam tespitini önlemek için mesajlar arasında bekleme süresi
                </p>
              </div>

              <Separator />

              {/* Gönderim Seçenekleri */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="rotation"
                    checked={useRotation}
                    onCheckedChange={(checked) => {
                      setUseRotation(checked as boolean);
                      if (checked) {
                        setSelectedSessions([]);
                      }
                    }}
                  />
                  <div className="flex items-center space-x-2">
                    <RotateCcw className="h-4 w-4 text-gray-600" />
                    <Label htmlFor="rotation" className="font-medium">
                      Rotasyon
                    </Label>
                  </div>
                </div>
                <p className="text-sm text-gray-600 ml-6">
                  Mesajları farklı session'lar arasında döngüsel olarak gönder
                </p>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="ai"
                    checked={useAI}
                    onCheckedChange={(checked) => setUseAI(checked as boolean)}
                  />
                  <div className="flex items-center space-x-2">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    <Label htmlFor="ai" className="font-medium">
                      AI Özgünleştirici
                    </Label>
                  </div>
                </div>
                <p className="text-sm text-gray-600 ml-6">
                  Her mesajı AI ile hafifçe farklılaştır
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Session Seçimi */}
          {!useRotation && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Session Seçimi</CardTitle>
                    <CardDescription>
                      Mesajları göndermek için kullanılacak session'ları seçin
                    </CardDescription>
                  </div>
                  {sessions.length > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSelectAllSessions}
                    >
                      {selectedSessions.length === sessions.length ? 'Tümünü Kaldır' : 'Tümünü Seç'}
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {sessionsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <RefreshCw className="h-6 w-6 animate-spin text-gray-400" />
                    <span className="ml-2 text-gray-600">Session'lar yükleniyor...</span>
                  </div>
                ) : sessions.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <AlertCircle className="h-8 w-8 mx-auto mb-2" />
                    <p>Aktif session bulunamadı</p>
                    <p className="text-sm mt-1">Session Manager'dan yeni session ekleyin</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {sessions.map((session) => (
                      <div key={session.id} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-gray-50 transition-colors">
                        <Checkbox
                          id={session.id}
                          checked={selectedSessions.includes(session.id)}
                          onCheckedChange={() => handleSessionToggle(session.id)}
                        />
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <Label htmlFor={session.id} className="font-medium cursor-pointer">
                              {session.label}
                            </Label>
                            <Badge variant="outline" className="text-xs">
                              +{session.phone}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">{session.name}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Gönder Butonu */}
          <Card>
            <CardContent className="pt-6">
              <Button
                onClick={handleBulkSend}
                disabled={isSending || !messageContent.trim() || phoneNumbersList.length === 0 || (!useRotation && selectedSessions.length === 0)}
                className="w-full h-14 bg-[#075E54] hover:bg-[#064e44] text-white font-medium text-lg"
                size="lg"
              >
                {isSending ? (
                  <div className="flex items-center space-x-3">
                    <RefreshCw className="h-5 w-5 animate-spin" />
                    <div className="text-left">
                      <div>Gönderiliyor... ({Math.round(progress)}%)</div>
                      <div className="text-sm opacity-80">
                        {currentSendingIndex}/{phoneNumbersList.length} • {estimatedTimeLeft}s kaldı
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Send className="h-5 w-5" />
                    <span>Toplu Mesaj Gönder ({phoneNumbersList.length} kişi)</span>
                  </div>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Sağ Panel - Sonuçlar ve İstatistikler */}
        <div className="space-y-6">
          {/* İstatistikler */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-green-600">{successCount}</div>
                <p className="text-sm text-gray-600">Başarılı</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-red-600">{errorCount}</div>
                <p className="text-sm text-gray-600">Hatalı</p>
              </CardContent>
            </Card>
          </div>

          {/* Progress Bar */}
          {isSending && (
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>İlerleme</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-3" />
                  <div className="flex justify-between text-xs text-gray-600">
                    <span>{currentSendingIndex}/{phoneNumbersList.length}</span>
                    <span>{estimatedTimeLeft}s kaldı</span>
                  </div>
                  {isPaused && (
                    <div className="flex items-center justify-center space-x-2 text-yellow-600 text-sm">
                      <Pause className="h-4 w-4" />
                      <span>Duraklatıldı</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Sonuçlar Listesi */}
          {results.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Gönderim Sonuçları</CardTitle>
                <CardDescription>
                  Son gönderim işleminin detayları
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[500px] overflow-y-auto">
                  {results.slice().reverse().map((result, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg">
                      <div className="flex-shrink-0">
                        {result.status === 'success' ? (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        ) : (
                          <AlertCircle className="h-5 w-5 text-red-600" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <p className="font-medium text-sm">{result.phoneNumber}</p>
                          {result.sessionUsed && (
                            <Badge variant="outline" className="text-xs">
                              {result.sessionUsed}
                            </Badge>
                          )}
                        </div>
                        <p className={`text-xs ${
                          result.status === 'success' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {result.message}
                        </p>
                        <p className="text-xs text-gray-500">{result.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Yardım */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Info className="h-5 w-5" />
                <span>Kullanım Kılavuzu</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-gray-600">
              <div>
                <strong>Numara Formatı:</strong> 90XXXXXXXXXX formatında girin (örn: 905551234567)
              </div>
              <div>
                <strong>Rotasyon:</strong> Mesajları farklı session'lar arasında döngüsel olarak gönderir
              </div>
              <div>
                <strong>AI Özgünleştirici:</strong> Her mesajı hafifçe farklılaştırarak daha doğal görünmesini sağlar
              </div>
              <div>
                <strong>Bekleme Süresi:</strong> Spam tespitini önlemek için mesajlar arasında bekleme süresi
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
} 